import React from "react";
import { Route, Routes } from "react-router-dom";
import AddPage from "./pages/AddPage";
import DetailPage from "./pages/DetailPage";
import HomePageWrapper from "./pages/HomePage";
import Header from "./components/Header";
import ArchivePageWrapper from "./pages/ArchivePage";

function App() {
  return (
    <div className="app-container">
      <Header />
      <main>
        <Routes>
          <Route path="/" element={<HomePageWrapper />} />
          <Route path="/add" element={<AddPage />} />
          <Route path="/archives" element={<ArchivePageWrapper />} />
          <Route path="/notes/:id" element={<DetailPage />} />
        </Routes>
      </main>
    </div>
  );
}

export default App;
